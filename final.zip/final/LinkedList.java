/**
 * Linked List implementation to store the dynamic array values.
 * It provides the functionality like Java linked list.
 *
 * @param <T> Type of objects which we want to insert in the list.
 */
public class LinkedList<T> implements ListInterface<T> {

    /**
     * Node clas to hold the data and its next object reference.
     */
    private class Node {
        /**
         * data to be stored.
         */
        T data;

        /**
         * Pointer to referring next element.
         */
        Node next;

        /**
         * Node class constructor to initialize.
         * @param data data to be added.
         */
        Node(T data) {
            this.data = data;
            this.next = null;
        }
    }

    /**
     * Head referring the first nod of the list.
     */
    private Node head;
    /**
     * Size of the array list.
     */
    private int size;

    /**
     * Constructor to initialize the Linked list.
     */
    protected LinkedList() {
        head = null;
        size = 0;
    }

    @Override
    public T set(T item, int index) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Index is out of bound.");
        }
        Node current = head;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        T existingData = current.data;
        current.data = item;
        return existingData;
    }

    @Override
    public T get(int index) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Index is out of bound.");
        }

        Node current = head;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        return current.data;
    }

    @Override
    public void add(T item, int index) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Index is out of bound.");
        }
        if (index == 0) {
            Node newNode = new Node(item);
            newNode.next = head;
            head = newNode;
        } else {
            Node previousNodeOfMentionedIndex = head;
            for (int i = 0; i < index - 1; i++) {
                previousNodeOfMentionedIndex = previousNodeOfMentionedIndex.next;
            }
            Node node = new Node(item);
            node.next = previousNodeOfMentionedIndex.next;
            previousNodeOfMentionedIndex.next = node;
        }
        size++;

    }

    @Override
    public T remove(int index) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Index is out of bound.");
        }
        T removedData;
        if (index == 0) {
            removedData = head.data;
            head = head.next;
        } else {
            Node previous = head;
            for (int i = 0; i < index - 1; i++) {
                previous = previous.next;
            }
            Node current = previous.next;
            removedData = current.data;
            previous.next = current.next;
        }
        size--;
        return removedData;
    }

    @Override
    public boolean contains(T item) {
        Node current = head;
        while (current != null) {
            if (current.data.equals(item)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public int getSize() {
        return size;
    }

    /**
     * Main method to test the standalone Linked list.
     * @param args arguments to specify.
     */
    public static void main(String[] args) {
        LinkedList<Integer> linkedList = new LinkedList<>();
        linkedList.add(10, 0);
        linkedList.add(20, 1);
        linkedList.add(30, 2);
        System.out.println(linkedList.get(1));
        System.out.println(linkedList.contains(40));

    }


}