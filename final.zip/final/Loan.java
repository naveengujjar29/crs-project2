/**
 * The Loan class represents a loan taken by a customer.
 * It includes details about the loan like loan ID, card type, limit, amount used,
 * status, creditor ID, and period ID.
 */
public class Loan {

    /**
     * The ID of the loan.
     */
    protected String loanID;

    /**
     * The type of the card associated with the loan.
     */
    protected String cardType;

    /**
     * The maximum limit for the loan.
     */
    protected double limit;

    /**
     * The amount of the loan that has already been used.
     */
    protected double amountUsed;

    /**
     * The status of the loan. It ranges from 1 to 5.
     */
    protected int status;

    /**
     * The ID of the creditor who issued the loan.
     */
    protected String creditorID;

    /**
     * The ID of the period for which the loan is valid.
     */
    protected String periodID;

    /**
     * Constructor for the Loan class. Initializes the loan with all details.
     *
     * @param loanID      the ID of the loan.
     * @param cardType    the type of card associated with the loan.
     * @param limit       the maximum loan limit.
     * @param amountUsed  the amount already used from the loan.
     * @param status      the current status of the loan.
     * @param creditorID  the ID of the creditor.
     * @param periodID    the ID of the period.
     *
     * @throws IllegalArgumentException if any of the input validations fail.
     */
    public Loan(String loanID, String cardType, double limit, double amountUsed, int status, String creditorID, String periodID) {
        isValidInputs(loanID, cardType, limit, amountUsed, status);
        this.loanID = loanID;
        this.cardType = cardType;
        this.limit = limit;
        this.amountUsed = amountUsed;
        this.status = status;
        this.creditorID = creditorID;
        this.periodID = periodID;
    }

    /**
     * Compares this loan to another object for equality.
     * Two loans are considered equal if they have the same loan ID and creditor ID.
     *
     * @param otherObject the object to compare to.
     * @return true if the loans are equal, false otherwise.
     */
    @Override
    public boolean equals(Object otherObject) {
        if (this == otherObject) {
            return true;
        }
        if (otherObject == null || getClass() != otherObject.getClass()) {
            return false;
        }
        Loan loan = (Loan) otherObject;
        return (this.loanID.equals(loan.loanID) && this.creditorID.equals(loan.creditorID));
    }

    /**
     * Validates the input values for the loan.
     *
     * @param loanID      the ID of the loan.
     * @param cardType    the type of card associated with the loan.
     * @param limit       the maximum loan limit.
     * @param amountUsed  the amount already used from the loan.
     * @param status      the current status of the loan.
     *
     * @throws IllegalArgumentException if any input value is invalid.
     */
    private void isValidInputs(String loanID, String cardType, double limit, double amountUsed, int status) {
        if (loanID == null || loanID.isEmpty()) {
            throw new IllegalArgumentException("Loan ID cannot be empty.");
        } else if (cardType == null || cardType.isEmpty()) {
            throw new IllegalArgumentException("Card Type cannot be null or empty.");
        } else if (limit < 500 && status != 5) {
            throw new IllegalArgumentException("Limit should be less than minimum value 500 for other status than 5.");
        } else if (limit != 0 && status == 5) {
            throw new IllegalArgumentException("Limit should be 0 for status 5.");
        } else if (amountUsed < 0) {
            throw new IllegalArgumentException("Used amount cannot be negative.");
        } else if (status < 1 || status > 5) {
            throw new IllegalArgumentException("Status must be between 1 and 5.");
        }
    }
}
