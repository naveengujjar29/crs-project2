import java.io.*;

import com.opencsv.*;

/**
 * This class is responsible to generate the report of specified SSN.
 */
public class CRS {
    /**
     * Set to hold the client list.
     */
    private static HashSet<Client> hashSet = new HashSet<>(100);
    /**
     * List to hold the creditors value.
     */
    private static LinkedList<String> listOfCreditors;

    //add creditors stack contents to the linkedlist listOfCreditors

    /**
     * This method convert the creditors from stack to list.
     *
     * @param creditors creditors list.
     */
    public static void setListOfCreditors(StackInterface<String> creditors) {
        listOfCreditors = new LinkedList<>();
        while (!creditors.isEmpty()) {
            String creditor = creditors.pop();
            listOfCreditors.add(creditor, listOfCreditors.getSize());
        }
    }

    //return array of files (all files in the folder folderName)

    /**
     * Get all the files inside the folder.
     *
     * @param folderName Under which input files to find
     * @return list of files
     */
    public static File[] getListOfFiles(String folderName) {
        File file = new File(folderName);
        if (file.exists() && file.isDirectory()) {
            return file.listFiles();
        } else {
            return new File[0];
        }
    }

    //load only data from the creditors added to the listOfCreditors to the hashSet
    //if a line contains invalid data (as per the validation rules provided, skip this line, do not stop the loading process)
    //the method will add only valid data to the hashset
    //return true if some data from the file were added to the dataset, false otherwise

    /**
     * This method will load the data from csv file and parse the information
     * and store it accordingly.
     *
     * @param file file to be parse out
     * @return true if any of the client information is being loaded.
     */
    public static boolean loadData(File file) {
        String fileName = file.getName();
        //remove the .csv from file name
        fileName = fileName.substring(0, fileName.length() - 4);
        String[] parts = fileName.split("_");
        String creditorId = parts[0];
        String period = parts[1];
        boolean dataAdded = false;
        if (!listOfCreditors.contains(creditorId)) {
            System.out.println("Provided creditor does not exist in creditor id.");
            return false;
        }
        try (CSVReader csvReader = new CSVReader(new FileReader(file))) {
            csvReader.readNext(); //CSV first line
            String[] input;
            while ((input = csvReader.readNext()) != null) {
                String ssn = input[0].trim();
                String firstName = input[1].trim();
                String lastName = input[2].trim();
                String jobTitle = input[3].trim();
                String employer = input[4].trim();
                String loanID = input[5].trim();
                String cardType = input[6].trim();
                double limit = Double.parseDouble(input[7].trim());
                double usedAmount = Double.parseDouble(input[8].trim());
                int status = Integer.parseInt(input[9].trim());
                Client client = new Client(ssn, creditorId);
                Client existingClient = hashSet.get(client);
                Loan loan = new Loan(loanID, cardType, limit, usedAmount, status, creditorId, period);
                if (existingClient != null) {
                    existingClient.otherName(firstName, lastName);
                    existingClient.loans.add(loan, existingClient.loans.getSize());
                } else {
                    client = new Client(ssn, firstName, lastName, jobTitle, employer, creditorId, period);
                    client.addLoan(loan);
                }
                hashSet.put(client);
                dataAdded = true;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (IllegalArgumentException ex) {
            System.out.println("Input is not valid, ignoring this line.");
        }
        return dataAdded;
    }

    /**
     * This method will generate the report of specified SSN.
     *
     * @param ssn SSN of the client.
     * @return Credit report summary.
     */
    public static String createReport(String ssn) {
        Client savedClient = null;
        for (int i = 0; i < listOfCreditors.getSize(); i++) {
            Client client = new Client(ssn, listOfCreditors.get(i));
            Client clientDetails = hashSet.get(client);
            if (savedClient == null && clientDetails != null) {
                savedClient = clientDetails;
            }
            if (savedClient != null && clientDetails != null) {
                savedClient.otherName(clientDetails.firstName, clientDetails.lastName, clientDetails.periodId);
                for (int j = 0; j < clientDetails.loans.getSize(); j++) {
                    savedClient.addLoan(clientDetails.loans.get(j));
                }
            }

        }

        return (savedClient == null) ? "" : savedClient.toString();
    }

    /**
     * Main method to execute to get the report of the client.
     *
     * @param args - argument to specified.
     */
    public static void main(String[] args) {

        //ONLY FOR TESTING PURPOSE...
        //Refer to the project description for expected ouput of createReport().

        //Provide the list of creditors to consider
        Stack<String> creditors = new Stack<>();
        creditors.push("C090");
        creditors.push("C099");

        //Move the creditors code from the stack to the list of creditors using the method setListOfCreditors
        setListOfCreditors(creditors);

        //Load data from the CSV files to the HashSet
        //1- Get all the files (ignoring the list of creditors)
        String folderPath = (args.length == 1) ? args[0] :"dataset";
        File[] files = getListOfFiles(folderPath);
        System.out.println("Files found in the dataset folder:" + files.length);
        int countFilesLoaded = 0;

        //2-Read files content (loadData() should return false if the file creditor ID is not in listOfCreditors)
        for (int i = 0; i < files.length; i++)
            if (loadData(files[i])) {
                countFilesLoaded++;
            }
        System.out.println("Files loaded into the hashset:" + countFilesLoaded);

        System.out.println("");

        //3-create report for a client        
        System.out.println(createReport("577-27-4193"));
    }
}
