/**
 * StackInterface defines the standard operations for
 * a generic stack data structure.
 *
 * @param <T> Type of data that on which we would like to operate.
 */
public interface StackInterface<T> {
    /**
     * Adds an item to the top of the stack.
     *
     * @param item the element to be pushed onto the stack
     */
    public void push(T item);

    /**
     * Removes and returns the item at the top of the stack.
     *
     * @return the item at the top of the stack
     */
    public T pop();

    /**
     * Returns the item at the top of the stack without removing it.
     *
     * @return the item at the top of the stack
     */
    public T peek();

    /**
     * Checks if the stack is empty.
     *
     * @return true if the stack contains no elements, false otherwise
     */
    public boolean isEmpty();

}

