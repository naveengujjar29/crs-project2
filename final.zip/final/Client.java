/**
 * Client class to hold the person and respective loan details.
 */
public class Client extends Person {

    /**
     * Job title of client.
     */
    protected String jobTitle;
    /**
     * Employer name.
     */
    protected String employer;
    /**
     * Creditor id.
     */
    protected String creditorID;
    /**
     * Period id of loan.
     */
    protected String periodId;
    /**
     * Loan details.
     */
    protected ListInterface<Loan> loans = new LinkedList<>();

    /**
     * Constructor to set the fields required to initialize the Client.
     * @param ssn SSN value
     * @param firstName  First Name
     * @param lastName Last Name
     * @param job Job detail
     * @param employer Employer
     * @param creditorID Creditor ID
     * @param period Period ID
     */
    public Client(String ssn, String firstName, String lastName, String job, String employer, String creditorID, String period) {
        super(ssn, firstName, lastName);
        validateInputs(job, employer);
        this.jobTitle = job;
        this.employer = employer;
        this.creditorID = creditorID;
        this.periodId = period;
    }

    /**
     * This method validates the inputs like job title and employer.
     * @param jobTitle Job Title
     * @param employer Employer detail.
     */
    private void validateInputs(String jobTitle, String employer) {
        if (jobTitle != null && jobTitle.length() < 4) {
            throw new IllegalArgumentException("If Job title is provided, it should be of 4 character length.");
        } else if (jobTitle != null && (employer == null || employer.length() < 4)) {
            throw new IllegalArgumentException("If Job title is provided, Employer can't be null or less than 4 characters.");
        }
    }

    /**
     * Constructor to create a Client with the specified SSN and creditor ID.
     *
     * @param ssn Social Security Number of the client.
     * @param creditorID Identifier of the creditor associated with the client.
     */
    protected Client(String ssn, String creditorID) {
        super(ssn);
        this.creditorID = creditorID;
    }

    @Override
    public boolean equals(Object otherObject) {
        if (this == otherObject) {
            return true;
        }
        if (otherObject == null || getClass() != otherObject.getClass()) {
            return false;
        }
        Client client = (Client) otherObject;
        return (this.ssn.equals(client.ssn) && this.creditorID.equals(client.creditorID));
    }

    /**
     * Adds a loan to the client's list of loans if it is not already present.
     *
     * @param loan the loan to be added
     */
    public void addLoan(Loan loan) {
        if (!loans.contains(loan)) {
            loans.add(loan, loans.getSize());
        }
    }

    /**
     * Updates the client's name if it differs from the current name and assigns a period identifier.
     *
     * @param firstName New first name of the client.
     * @param lastName  New last name of the client.
     * @param periodID  Period identifier to be assigned.
     * @return true if the name was successfully updated, false otherwise.
     */
    public boolean otherName(String firstName, String lastName, String periodID) {
        super.otherName(firstName, lastName);
        this.periodId = periodID;
        return true;
    }

    /**
     * Returns a string representation of the Client object, including
     * personal information, loan details, and metadata such as the
     * submitting creditor and the last update period.
     *
     * @return a string containing the client's personal information and loan details
     */
    public String toString() {
        String personInformation = super.toString();
        double totalAmountUsed = 0;
        double currentUsedAmount = 0;
        int currentAccounts = 0;
        double notCurrentUsedAmount = 0;
        double chargeOff = 0;
        for (int i = 0; i < loans.getSize(); i++) {
            totalAmountUsed += loans.get(i).amountUsed;
            if (loans.get(i).status == 1) {
                currentUsedAmount += loans.get(i).amountUsed;
                currentAccounts++;
            }
            if (loans.get(i).status == 5) {
                chargeOff += loans.get(i).amountUsed;
            }

        }
        notCurrentUsedAmount = totalAmountUsed - currentUsedAmount;
        int nonCurrentAccount = loans.getSize() - currentAccounts;
        String totalLoanLine = loans.getSize() + " -- " + "Total Used Amount: " + totalAmountUsed;
        String currentLoanLine = currentAccounts + " -- " + "Total Used Amount: " + currentUsedAmount;
        String nonCurrentLoanLine = nonCurrentAccount + " -- " + "Total Used Amount: " + notCurrentUsedAmount;

        String output = personInformation + "\nLoans\t\t:" + totalLoanLine + "\n- Current\t:" + currentLoanLine +
                "\n- Not Current\t:" + nonCurrentLoanLine + "\n- ChargeOff\t:" + chargeOff +
                "\n\n\t- Submitted by:" + creditorID + "\n\t- Last Update:" + periodId;
        return output;
    }

    /**
     * Hash code of ssn.
     * @return ssn hash code.
     */
    public int hashCode() {
        //Your code HERE.
        //2 client instances with same ssn should have the same hashcode.
        return ssn.hashCode();
    }

    /**
     * Testing method of this class.
     * @param args arguments to pass for main method.
     */
    public static void main(String[] args) {
        //Add more tests...
        Client c = new Client("577-27-4193", "Adrien", "Feldmann", "Sales Associate", "Jenkins Inc", "C090", "202408");
        System.out.println(c);
    }
}
