/**
 * The Person class represents an individual with a social security number (SSN),
 * a first name, and a last name. It can also store other names associated with the person.
 */
public class Person {

    /**
     * The social security number (SSN) of the person in the format 000-00-0000.
     */
    protected String ssn;

    /**
     * The first name of the person.
     */
    protected String firstName;

    /**
     * The last name of the person.
     */
    protected String lastName;

    /**
     * A list of other names associated with the person.
     */
    protected ListInterface<String> otherNames = new LinkedList<>();

    /**
     * Constructor that initializes the person with just an SSN.
     * No validation is done here.
     *
     * @param ssn the SSN of the person.
     */
    protected Person(String ssn) {
        this.ssn = ssn;
    }

    /**
     * Constructor that initializes the person with an SSN, first name, and last name.
     * All arguments are validated based on the provided rules.
     *
     * @param ssn        the SSN of the person.
     * @param firstName  the first name of the person.
     * @param lastName   the last name of the person.
     * @throws IllegalArgumentException if any of the validation rules are violated.
     */
    public Person(String ssn, String firstName, String lastName) {
        isValidInput(ssn, firstName, lastName);
        this.ssn = ssn;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * Adds a new name to the list of other names if it's different from the current name.
     *
     * @param firstName the first name to be checked and added.
     * @param lastName  the last name to be checked and added.
     * @return true if the name was added, false if it's the same as the current name.
     */
    public boolean otherName(String firstName, String lastName) {
        if (!(this.firstName.equals(firstName) && this.lastName.equals(lastName))) {
            otherNames.add(firstName + " " + lastName, otherNames.getSize());
            return true;
        }
        return false;
    }

    /**
     * Returns a string representation of the person.
     * It includes the first name, last name, SSN, and any other names the person has.
     *
     * @return a formatted string with the person's details.
     */
    public String toString() {
        StringBuilder otherName = new StringBuilder();
        for (int i = 0; i < otherNames.getSize(); i++) {
            otherName.append(otherNames.get(i));
            if (i < otherNames.getSize() - 1) {
                otherName.append(", ");
            }
        }
        return "First name\t:" + this.firstName + "\nLast Name\t:" + this.lastName
                + "\nSSN\t\t:" + this.ssn + "\nOther Name\t:" + otherName.toString();
    }

    /**
     * Validates the input values for the SSN, first name, and last name.
     *
     * @param ssn        the SSN to be validated.
     * @param firstName  the first name to be validated.
     * @param lastName   the last name to be validated.
     * @throws IllegalArgumentException if any validation fails.
     */
    private void isValidInput(String ssn, String firstName, String lastName) {
        if (!ssn.matches("\\d{3}-\\d{2}-\\d{4}")) {
            throw new IllegalArgumentException("Invalid SSN. SSN should be in 000-00-0000 format.");
        } else if (firstName == null || firstName.length() < 2) {
            throw new IllegalArgumentException("Invalid firstName. First Name should be at least 2 char length.");
        } else if (lastName == null || lastName.length() < 2) {
            throw new IllegalArgumentException("Invalid lastName. Last Name should be at least 2 char length.");
        }
    }

    /**
     * Main method for testing the Person class.
     * Creates a Person object and adds other names.
     *
     * @param args command-line arguments (not used).
     */
    public static void main(String[] args) {
        Person p = new Person("577-27-4193", "Adrien", "Feldmann");
        p.otherName("Adrian", "Feldmann");
        p.otherName("Adrian", "Feldman");
        System.out.println(p);
    }
}
