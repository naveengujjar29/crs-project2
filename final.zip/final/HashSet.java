/**
 * The HashSet class implements a hash table that uses a hash function
 * to determine the index of the bucket where values
 * will be stored.
 *
 * @param <T> the type of elements maintained by this set
 */
public class HashSet<T> {

    /**
     * Bucket table to store the values on indexes.
     */
    private LinkedList<T>[] table;

    /**
     * Capacity of hash set.
     */
    private int capacity;

    /**
     * Size of elements is being inserted.
     */
    private int size;

    /**
     * Load factor of map to resize.
     * Java default loadFactor is also 0.75.
     */
    private double loadFactor;

    /**
     * Constructor to initialize the Hashset with initial capacity.
     *
     * @param capacity initial capacity.
     */
    public HashSet(int capacity) {
        this(capacity, 0.75);
    }

    @SuppressWarnings("unchecked")
    public HashSet(int capacity, double loadFactor) {
        if (loadFactor > 1) {
            throw new IllegalArgumentException("Load factor cannot be greater than 1");
        }
        this.capacity = capacity;
        this.size = 0;
        this.loadFactor = loadFactor;
        table = new LinkedList[capacity];
        for (int i = 0; i < capacity; i++) {
            table[i] = new LinkedList<>();
        }
    }

    /**
     * Hash computing function.
     *
     * @param value Value to be hashed.
     * @return hashed value.
     */
    // Hash function to determine the bucket index
    private int hash(T value) {
        return Math.abs(value.hashCode() % capacity);
    }

    /**
     * This function will put the value after computing the hash value
     * on that specified index and if equals then override else
     * append to existing data.
     *
     * @param value Value to be inserted
     * @return whether data is being inserted properly or not.
     */
    // Adds a value to the HashSet (if not already present)
    public boolean put(T value) {
        int index = hash(value);
        LinkedList<T> bucket = table[index];

        if (!bucket.contains(value)) {
            resizeIfNeeded();
            bucket.add(value, bucket.getSize()); // Add at the end of the LinkedList
            size++;
            return true; // Value added successfully
        }
        return false; // Value already exists, no addition
    }

    // Retrieves a value from the HashSet

    /**
     * Find the respective value in HashSet.
     *
     * @param value Value to be get
     * @return return the respective object assigned with that value.
     */
    public T get(T value) {
        int index = hash(value);
        LinkedList<T> bucket = table[index];

        for (int i = 0; i < bucket.getSize(); i++) {
            T current = bucket.get(i);
            if (current.equals(value)) {
                return current; // Value found in the set
            }
        }
        return null; // Value not found
    }


    /**
     * Checks if the current load factor exceeds the threshold and resizes if needed.
     */
    private void resizeIfNeeded() {
        if (size >= capacity * loadFactor) {
            expandTheHashTable();
        }
    }

    /**
     * Resize the table;
     */
    @SuppressWarnings("unchecked")
    private void expandTheHashTable() {
        int newCapacity = capacity * 2;
        LinkedList<T>[] newTable = new LinkedList[newCapacity];
        for (int i = 0; i < newCapacity; i++) {
            newTable[i] = new LinkedList<>();
        }

        for (LinkedList<T> bucket : table) {
            for (int i = 0; i < bucket.getSize(); i++) {
                T value = bucket.get(i);
                int newIndex = Math.abs(value.hashCode() % newCapacity);
                newTable[newIndex].add(value, newTable[newIndex].getSize());
            }
        }
        table = newTable;
        capacity = newCapacity;
    }
}
