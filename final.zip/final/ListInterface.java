/**
 * Interface having Linked list method definition.
 * @param <T> Type of object to interact with.
 */
public interface ListInterface<T> {

    /**
     * Replaces the element at the specified index with the given item.
     *
     * @param item  the element to replace the current one
     * @param index the position of the element to be replaced
     * @return the element previously at the specified index
     * @throws IndexOutOfBoundsException if the index is out of range
     */
    public T set(T item, int index);

    /**
     * Returns the element at the specified index.
     *
     * @param index the position of the element to retrieve
     * @return the element at the specified index
     * @throws IndexOutOfBoundsException if the index is out of range
     */
    public T get(int index);

    /**
     * Inserts the specified item at the given index.
     *
     * @param item  the element to be added
     * @param index the position where the element should be inserted
     * @throws IndexOutOfBoundsException if the index is out of range
     */
    public void add(T item, int index);

    /**
     * Removes the element at the specified index.
     *
     * @param index the position of the element to be removed
     * @return the element that was removed
     * @throws IndexOutOfBoundsException if the index is out of range
     */
    public T remove(int index);

    /**
     * Checks if the list contains the specified item.
     *
     * @param item the element to look for
     * @return true if the list contains the item, false otherwise
     */
    public boolean contains(T item);

    /**
     * Checks if the list is empty.
     *
     * @return true if the list contains no elements, false otherwise
     */
    public boolean isEmpty();

    /**
     * Returns the number of elements in the list.
     *
     * @return the size of the list
     */
    public int getSize();


}
