/**
 * A generic stack implementation that provides standard stack operations.
 * This stack follows a Last-In-First-Out (LIFO) principle.
 *
 * @param <T> the type of elements stored in this stack
 */
public class Stack<T> implements StackInterface<T> {

    /**
     * Represents a node in a linked list structure used within the Stack class.
     */
    private class Node {
        /**
         * The data held by this node in the linked list.
         * This can be of any type specified by the generic type T.
         */
        T data;

        /**
         * A reference to the next node in the linked list.
         * If this is the last node, next is null.
         */
        Node next;

        /**
         * Constructs a new node with the specified data.
         *
         * @param data data to be stored.
         */
        Node(T data) {
            this.data = data;
            this.next = null;
        }
    }

    /**
     * A reference to the top node in the stack.
     * This node represents the most recently added element and
     * Points to the top of the stack
     */
    private Node top;


    /**
     * Holds the current number of elements in the stack.
     * This value is incremented when an item is pushed onto the stack
     * and decremented when an item is popped.
     */
    private int size;

    /**
     * Constructs an empty Stack.
     * Initializes the stack with no elements by setting the top to null
     * and the size to zero.
     */
    public Stack() {
        top = null;
        size = 0;
    }

    @Override
    public void push(T item) {
        Node newNode = new Node(item);
        newNode.next = top;
        top = newNode;
        size++;
    }

    @Override
    public T pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        T poppedData = top.data;
        top = top.next;
        size--;
        return poppedData;
    }

    @Override
    public T peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return top.data;
    }

    @Override
    public boolean isEmpty() {
        return top == null;
    }

    /**
     * main method to test the stack operations functionality.
     *
     * @param args arguments which we can pass.
     */
    public static void main(String[] args) {

    }
}

